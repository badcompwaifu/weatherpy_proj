# Weatherpy

A simple weather forecast app. Type a location and it will give weather data from that location, plain and simple.

Uses API data from openweathermap



