from django.contrib import admin
from weatherpy.models import MessagesDb


admin.site.register(MessagesDb)
