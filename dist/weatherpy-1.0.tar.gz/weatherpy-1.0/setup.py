from setuptools import setup, find_packages

setup(
    name='weatherpy',
    version='1.0',
    author='kamo',
    packages=find_packages(),
)
